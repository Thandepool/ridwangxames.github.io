javascript: (function () { document.body.style.filter = 'blur(5px)'; })();
