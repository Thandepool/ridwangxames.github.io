# my server:
<a href="https://discord.gg/hrXXUeWgrn">
  <img src="https://raw.githubusercontent.com/dragon731012/dragon731012/main/0.jpg" width="600px" height="230px"/>
</a>

# how to use:

for bookmarklets (the ones without .html):

1. highlight all of the text

2. drag it to your bookmarks bar

3. click it when you want to run it

OR

1. copy whole thing.

2. type javascript: into your url bar.

3. paste it

for html (ones with .html):

1. if view raw option avalible, click it.

2. right click over raw space.

3. click save as

4. click file when you want to play

for zip ones (ones with .zip):

1. download

2. double click file until you see main.html or index.html

3. play it

# my and my contributor's involvement with these

We only made some of these, and we are not responsible for any of them. By using these, you agree to those terms. If you have a reasonable objection to something being on this respiratory, tell me and I'll remove it immediately.

# other
If you have any issues or ideas, please tell me in discussions (https://github.com/dragon731012/-WORKING-bookmarklets-and-games/discussions/2).

Please enter my code 8B6M1B on fetch and get some fetch coins! https://referral.fetch.com/vvv3/referraltext?code=8B6M1B
